from django.apps import AppConfig


class HousesConfig(AppConfig):
    name = 'houses'
    verbose_name = "Дома"
